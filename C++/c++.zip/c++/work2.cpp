#include <iostream>
using namespace std;

int main() {
    int age = 20;  // Integer variable
    double price = 19.99;  // Double variable
    char grade = 'A';  // Character variable
    string name = "HESHIMA Herbert";  // String variable

    cout << "Name: " << name << endl;
    cout << "Age: " << age << endl;
    cout << "Price: $" << price << endl;
    cout << "Grade: " << grade << endl;
    
    return 0;
}
